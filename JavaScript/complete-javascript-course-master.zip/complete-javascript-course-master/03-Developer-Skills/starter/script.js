// Remember, we're gonna use strict mode in all scripts now!
'use strict';

